import sys

import cv2
from munkres import Munkres
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from skimage import color
from sklearn.decomposition import PCA
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import normalized_mutual_info_score  # NMI
from sklearn.metrics import rand_score  # RI
from sklearn.metrics import accuracy_score  # ACC
from sklearn.metrics import f1_score  # F-measure
from sklearn.metrics import adjusted_rand_score  # ARI
from sklearn.metrics import confusion_matrix,adjusted_mutual_info_score, rand_score, fowlkes_mallows_score, adjusted_rand_score, \
    normalized_mutual_info_score, accuracy_score,precision_score, recall_score, f1_score

from face_data import read_directory, colorize
from sklearn.neighbors import KNeighborsClassifier
sys.path.append("../..")
import matplotlib
matplotlib.use('TkAgg')

##图片数据集函数
# def load_faces_data(path):
#     faces = []
#     # 数据集数目  olivetti
#     for i in range(1, 11):  # 获取每个文件夹下的图片的路径，总共有400个路径放在faces里
#     # coil20
#     # for i in range(1, 16):  # 获取每个文件夹下的图片的路径，总共有400个路径放在faces里
#         file_addr = read_directory(path + "/s" + str(i))
#         for addr in file_addr:
#             faces.append(addr)
#     images = []
#     label = []
#     for index, face in enumerate(faces):
#         image = cv2.imread(face, 0)
#         images.append(image)
#         label.append(int(index / 10 + 1))
#     return images, label
# def PCA_images(images, label):
#     image_data = []
#     label_ = []
#     print("Number of images:", len(images))
#     for i in range(len(images)):
#         data = images[int(i / 10) * 10 + i % 10].flatten()  # 把100*112*92的三维数组变成100*10304的二维数组
#         label_.append(label[int(i / 10) * 10 + i % 10])
#         image_data.append(data)
#     X = np.array(image_data)  # 每个图像数据降到一维后的列表
#     data = pd.DataFrame(X)  # 打印的话，X可以显示列和行号的
#     pca = PCA(.92)
#     pca.fit(X)
#     PCA_data = pca.transform(X)
#     expained_variance_ratio = pca.explained_variance_ratio_.sum()  # 计算保留原始数据的多少
#
#     # 看降到i维的保留原始数据的曲线图
#     # expained_variance_ratio = []
#     # for i in range(1,200):
#     #     pca = PCA(n_components=i).fit(X)#构建pca降维器
#     #     expained_variance_ratio.append(pca.explained_variance_ratio_.sum())#计算每次降维，所带的数据是原始数据的多少
#     #     print(i,pca.explained_variance_ratio_.sum())
#     # plt.plot(range(1,160),expained_variance_ratio)
#     # plt.show()
#     # V = pca.components_#pca中间的转换矩阵，让10304*100转换成100*98的矩阵
#
#     return PCA_data, label_
#
# def plot_image2(images, label, name):
#     # fig,axes = plt.subplots(1,1)
#     aspect = 1.
#     n = 10  # number of rows
#     m = 10  # numberof columns
#     bottom = 0.1
#     left = 0.05
#     top = 1. - bottom
#     right = 1. - 0.18
#     fisasp = (1 - bottom - (1 - top)) / float(1 - left - (1 - right))
#     # widthspace, relative to subplot size
#     wspace = 0  # set to zero for no spacing
#     hspace = wspace / float(aspect)
#     # fix the figure height
#     figheight = 50  # inch
#     figwidth = (m + (m - 1) * wspace) / float((n + (n - 1) * hspace) * aspect) * figheight * fisasp
#     fig, axes = plt.subplots(nrows=n, ncols=m, figsize=(figwidth, figheight))
#     plt.subplots_adjust(top=top, bottom=bottom, left=left, right=right,
#                         wspace=wspace, hspace=hspace)
#     hue_rotations = np.linspace(0, 2, 20)
#     for i, ax in enumerate(axes.flat):
#         image1 = color.gray2rgb(images[int(i / 10) * 10 + i % 10])
#         image1 = colorize(image1, hue_rotations[int(label[i]) - 1], saturation=0.5)
#         ax.imshow(image1)
#         ax.axis('off')
#     plt.savefig(name)
#     plt.show()

##文本数据路径及预处理
# 数据保存在.csv文件中
# iris = pd.read_csv("../../datasets/iris.csv", header=0)  # 鸢尾花数据集 Iris  class=3
# wine = pd.read_csv("../../datasets/wine.csv")  # 葡萄酒数据集 Wine  class=3
# seeds = pd.read_csv("../../datasets/seeds.csv")  # 小麦种子数据集 seeds  class=3
# wdbc = pd.read_csv("../../datasets/wdbc.csv")  # 威斯康星州乳腺癌数据集 Breast Cancer Wisconsin (Diagnostic)  class=2
# glass = pd.read_csv("../../datasets/glass.csv")  # 玻璃辨识数据集 Glass Identification  class=6
# jain = pd.read_csv("../../datasets/Jain.csv")  # 人工数据集
# spiral = pd.read_csv("../../datasets/spiral.csv")  # 人工数据集
# flame = pd.read_csv("../../datasets/Flame.csv")  # 人工数据集
# aggregation = pd.read_csv("../../datasets/Aggregation.csv")  # 人工数据集
# df = pd.read_csv("../../datasets/Pathbased.csv")
# df = pd.read_csv("../../datasets/R15.csv")
# df = pd.read_csv("../../datasets/Flame.csv")
# df = pd.read_csv("../../datasets/Iris2.csv")
# df = pd.read_csv("../../datasets/Wine.csv")
# df = pd.read_csv("../../datasets/ecoli2.csv")
# df = pd.read_csv("../../datasets/newthyroid-snn.csv")
# df = pd.read_csv("../../datasets/wdbc.csv")
# df = pd.read_csv("../../datasets/zoo-snn.csv")
# df = pd.read_csv("../../datasets/pima/diabetes.csv")
# df = pd.read_csv("../../datasets/glass.csv")
# df = pd.read_csv("../../datasets/ionosphere.csv")
df = pd.read_csv("../../datasets/new3.csv")


# 自动生成列名：例如 feature1, feature2, ...
df.columns = [f'feature{i+1}' for i in range(df.shape[1])]

# 打印数据查看效果
print(df)
# 获取所有列名
columns = list(df.columns)

# 提取特征名（去除最后一列作为标签列）
features = columns[:len(columns) - 1]

# 取出特征数据集
dataset = df[features]

# 获取属性数量（即特征列数）
attributes = len(df.columns) - 1

# 获取原始标签（最后一列）
original_labels = list(df[columns[-1]])


##图片数据集
# path = "../../datasets/att_faces"
# # path = "../../datasets/coil201"
# # k = 4
# nc = 10
# images, original_labels = load_faces_data(path)
# # 通过 主成分分析 (PCA) 降低图像数据的维度
# datas, label_ = PCA_images(images, original_labels)
# name = "../../datasets/output_image" + "/" + "coil-dpc.png"
# plot_image2(images, label_, name)

print(f"Dataset:\n{dataset}")

# KNN分类
def dp_knn_with_dpc_centers(X_train, y_train, X_test, k=5):
    # 使用 DPC 生成的聚类中心作为训练集的代表点
    knn = KNeighborsClassifier(n_neighbors=k)

    # 对于测试集，使用 KNN 分类
    knn.fit(X_train, y_train)
    y_pred = knn.predict(X_test)

    return y_pred
# 计算数据点两两之间的距离
def getDistanceMatrix(datas):
    N, D = np.shape(datas)
    dists = np.zeros([N, N])

    for i in range(N):
        for j in range(N):
            vi = datas[i, :]
            vj = datas[j, :]
            dists[i, j] = np.sqrt(np.dot((vi - vj), (vi - vj)))
    return dists


# 找到密度计算的阈值dc
# 要求平均每个点周围距离小于dc的点的数目占总点数的1%-2%
def select_dc(dists):
    N = np.shape(dists)[0]
    tt = np.reshape(dists, N * N)
    percent = 5.0
    position = int(N * (N - 1) * percent / 100)
    dc = np.sort(tt)[position + N]
    return dc


# 计算每个点的局部密度
def get_density(dists, dc, method=None):
    N = np.shape(dists)[0]
    rho = np.zeros(N)

    for i in range(N):
        if method == None:
            rho[i] = np.where(dists[i, :] < dc)[0].shape[0] - 1
        else:
            rho[i] = np.sum(np.exp(-(dists[i, :] / dc) ** 2)) - 1
    return rho


# 计算每个数据点的密度距离
# 即对每个点，找到密度比它大的所有点
# 再在这些点中找到距离其最近的点的距离
def get_deltas(dists, rho):
    N = np.shape(dists)[0]
    deltas = np.zeros(N)
    nearest_neiber = np.zeros(N)
    # 将密度从大到小排序
    index_rho = np.argsort(-rho)
    for i, index in enumerate(index_rho):
        # 对于密度最大的点
        if i == 0:
            continue

        # 对于其他的点
        # 找到密度比其大的点的序号
        index_higher_rho = index_rho[:i]
        # 获取这些点距离当前点的距离,并找最小值
        deltas[index] = np.min(dists[index, index_higher_rho])

        # 保存最近邻点的编号
        index_nn = np.argmin(dists[index, index_higher_rho])
        nearest_neiber[index] = index_higher_rho[index_nn].astype(int)

    deltas[index_rho[0]] = np.max(deltas)
    return deltas, nearest_neiber


# 选取rho与delta乘积较大的点作为聚类中心
def find_centers(rho, deltas, K=0):
    if K == 0:
        # 没有手动设置聚类数K，通过阈值选取rho与delta都大的点
        rho_threshold = (np.min(rho) + np.max(rho)) / 2
        delta_threshold = (np.min(deltas) + np.max(deltas)) / 2
        N = np.shape(rho)[0]
        centers = []
        for i in range(N):
            if rho[i] >= rho_threshold and deltas[i] > delta_threshold:
                centers.append(i)
        return np.array(centers)
    else:
        # 手动输入聚类数K，选取rho与delta乘积最大的K个点作为聚类中心，作为k个中心点
        rho_delta = rho * deltas
        centers = np.argsort(-rho_delta)
        return centers[:K]


def cluster_PD(rho, centers, nearest_neiber):
    K = np.shape(centers)[0]
    if K == 0:
        print("can not find centers")
        return

    N = np.shape(rho)[0]
    label = -1 * np.ones(N).astype(int)

    # 首先对几个聚类中进行标号
    for i, center in enumerate(centers):
        label[center] = i

    # 将密度从大到小排序
    index_rho = np.argsort(-rho)
    for i, index in enumerate(index_rho):
        # 从密度大的点进行标号
        if label[index] == -1:
            # 如果没有被标记过
            # 那么聚类标号与距离其最近且密度比其大
            # 的点的标号相同
            label[index] = label[int(nearest_neiber[index])]
    return label


def draw_decision(rho, deltas):
    plt.cla()
    for i in range(np.shape(datas)[0]):
        plt.scatter(rho[i], deltas[i], s=16., color=(0, 0, 0))
        plt.annotate(str(i), xy=(rho[i], deltas[i]), xytext=(rho[i], deltas[i]))
        plt.xlabel("rho")
        plt.ylabel("deltas")
    # plt.savefig(filename+"_decision.jpg")
    plt.show()


# 计算聚类指标
def clustering_indicators(labels_true, labels_pred):
    if type(labels_true[0]) != int:
        labels_true = LabelEncoder().fit_transform(df[columns[len(columns) - 1]])  # 如果标签为文本类型，把文本标签转换为数字标签
    f_measure = f1_score(labels_true, labels_pred, average='macro')  # F值
    accuracy = accuracy_score(labels_true, labels_pred)  # ACC
    normalized_mutual_information = normalized_mutual_info_score(labels_true, labels_pred)  # NMI
    rand_index = rand_score(labels_true, labels_pred)  # RI
    ARI = adjusted_rand_score(labels_true, labels_pred)
    return f_measure, accuracy, normalized_mutual_information, rand_index, ARI


def draw_cluster(datas, label, centers):
    plt.cla()
    K = np.shape(centers)[0]
    colors = np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta", "beige", "hotpink", "#88c999"])
    if attributes > 2:
        datas = PCA(n_components=2).fit_transform(datas)  # 如果属性数量大于2，降维
    for i in range(K):
        plt.scatter(datas[np.nonzero(label == i), 0], datas[np.nonzero(label == i), 1], c=colors[i], s=7)
        # plt.scatter(datas[centers[i], 0], datas[centers[i], 1], color="k", marker="+", s=200.)  # 聚类中心
    # plt.savefig(file_name + "_cluster.jpg")
    # 设置x和y坐标轴刻度的标签字体和字号
    plt.xticks(fontproperties='Times New Roman', fontsize=10.5)
    plt.yticks(fontproperties='Times New Roman', fontsize=10.5)
    plt.show()

def best_map(L1, L2):
        Label1 = np.unique(L1)  # 去除重复的元素，由小大大排列
        nClass1 = len(Label1)  # 标签的大小
        Label2 = np.unique(L2)
        nClass2 = len(Label2)
        # print("Label1 unique:", np.unique(L1))
        # print("Label2 unique:", np.unique(L2))
        for label in Label2:
            if label not in Label1:
                Label1 = np.append(Label1, label)
        nClass = np.maximum(nClass1, nClass2)
        G = np.zeros((nClass, nClass))
        for i in range(nClass1):
            ind_cla1 = L1 == Label1[i]
            ind_cla1 = ind_cla1.astype(float)
            for j in range(nClass2):
                ind_cla2 = L2 == Label2[j]
                ind_cla2 = ind_cla2.astype(float)
                G[i, j] = np.sum(ind_cla2 * ind_cla1)
        m = Munkres()
        index = m.compute(-G.T)
        index = np.array(index)
        c = index[:, 1]
        newL2 = np.zeros(L2.shape)
        # print(f"Label1 size: {len(Label1)}, Label2[i]: {len(Label2)}, c[i]: {len(c)}")

        for i in range(nClass2):
            newL2[L2 == Label2[i]] = Label1[c[i]]
        return newL2
if __name__ == "__main__":

    # # 主程序
    datas = np.array(dataset).astype(np.float64)
    # # 计算距离矩阵
    dists = getDistanceMatrix(datas)

    # 计算dc
    dc = select_dc(dists)
    print("dc", dc)
    # 计算局部密度ρ
    rho = get_density(dists, dc, method="Gaussion")
    # 计算密度距离δ
    deltas, nearest_neiber = get_deltas(dists, rho)


    scaler = StandardScaler()
    data = scaler.fit_transform(datas)
    # 绘制密度/距离分布图
    # draw_decision(rho, deltas)
    # 获取聚类中心点
    centers = find_centers(rho, deltas,14)
    print("centers", centers)
    label = cluster_PD(rho, centers, nearest_neiber)
    plt.cla()
    K = np.shape(centers)[0]
    X_train = datas[centers]  # 使用聚类中心作为训练集
    y_train = label[centers]  # 使用聚类标签作为训练标签

    # 对测试集进行 KNN 分类
    X_test = datas  # 以整个数据集作为测试集
    y_pred = dp_knn_with_dpc_centers(X_train, y_train, X_test, k=5)

    precision = precision_score(original_labels, y_pred, average='macro')  # Precision
    recall = recall_score(original_labels, y_pred, average='macro')  # Recall
    f1 = f1_score(original_labels, y_pred, average='macro')  # F1-score
    acc = accuracy_score(original_labels, y_pred)  # Accuracy
    ari = adjusted_rand_score(original_labels, y_pred)  # ARI
    nmi = normalized_mutual_info_score(original_labels, y_pred)  # NMI
    cm = confusion_matrix(original_labels, y_pred)
    # 打印分类指标
    print(f"Precision: {precision:.3f}")
    print(f"Recall: {recall:.3f}")
    print(f"F1-score: {f1:.3f}")
    print(f"Accuracy: {acc:.3f}")
    print(f"Adjusted Rand Index (ARI): {ari:.3f}")
    print(f"Normalized Mutual Information (NMI): {nmi:.3f}")
    FP = cm[0][1]
    TN = cm[0][0]
    FR = FP / (FP + TN) if (FP + TN) > 0 else 0
    print(f"False Alarm Rate (FR): {FR:.3f}")
    # acc = lambda x, y: accuracy_score(x, y)
    # ari = lambda x, y: adjusted_rand_score(x, y)
    # ami = lambda x, y: adjusted_mutual_info_score(x, y)
    # fmi = lambda x, y: fowlkes_mallows_score(x, y)
    # nmi = lambda x, y: normalized_mutual_info_score(x, y)
    #
    # newL2 = best_map(original_labels, label)
    # precision = precision_score(original_labels, newL2, average='macro')  # 多类别计算时可以使用 'micro', 'macro', 'weighted' 等
    # recall = recall_score(original_labels, newL2, average='macro')
    # f1 = f1_score(original_labels, newL2, average='macro')
    # cm = confusion_matrix(original_labels, newL2)

    # Extract FP and TN from confusion matrix
    # FP = cm[0][1]
    # TN = cm[0][0]
    #
    # # Calculate False Alarm Rate (FR)
    # FR = FP / (FP + TN) if (FP + TN) > 0 else 0
    # 输出结果
    # print(original_labels)
    # print(label)
    # print(newL2)
    # print(f"Precision: {precision:.3f}")
    # print(f"Recall: {recall:.3f}")
    # print(f"F1-score: {f1:.3f}")
    # print("%.3f,%.3f,%.3f" % (acc(original_labels, newL2), ari(original_labels, newL2), ami(original_labels, newL2)))
    # print(f"False Alarm Rate (FR): {FR:.3f}")
    # draw_cluster(datas, label, centers)